<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Lago_module extends ClientsController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('lago_model');
    }
    
 
    public function index()
    {
        // Get raw input from the request body
        $rawData = file_get_contents("php://input");
        // Decode the raw input if it's in JSON format
        $data = json_decode($rawData, true);
        
        // Check Invoice Exists
        $isCheck = (isset($data['invoice']['lago_id']) && $this->lago_model->isLagoInvoiceCheck($data['invoice']['lago_id']));
        // If 'lago_id' is not set or is null, set $isCheck to false
        $isCheck = $isCheck ?? false;

       
        if(isset($data['invoice']) && $this->input->method() == 'post' && $isCheck == true){
                
                $trimmedHash = substr(md5( $data['invoice']['number'] ), 0, 30);
                // Array For Invoice Table 
                $invoiceData = array(
                    'sent' => 0,
                    'datesend' => null,
                    'clientid' => $data['invoice']['customer']['external_id'],
                    'deleted_customer_name' => null,
                    'number' => 0,
                    'prefix' => "INV-",
                    'number_format' => 1,
                    'datecreated' => $data['invoice']['customer']['created_at'],
                    'date' => $data['invoice']['issuing_date'],
                    'duedate' => $data['invoice']['payment_due_date'],
                    'currency' => 1,
                    'subtotal' => $data['invoice']['amount_cents']/100,
                    'total_tax' => $data['invoice']['vat_amount_cents']/100,
                    'total' => $data['invoice']['total_amount_cents']/100,
                    'adjustment' =>  0,
                    'addedfrom' => 9,
                    'hash' => $trimmedHash ,
                    'status' => 1,
                    'last_overdue_reminder' => null,
                    'last_due_reminder' => null,
                    'cancel_overdue_reminders' => 0,
                    'allowed_payment_modes' => serialize(["hyperswitch"]),
                    'token' => null,
                    'discount_percent' => 0,
                    'discount_total' => 0,
                    'recurring' => 0,
                    'recurring_type' => null ,
                    'custom_recurring' => 0,
                    'cycles' => 0,
                    'total_cycles' => 0,
                    'sale_agent' => 1 ,
                    'billing_country' => null,
                    'include_shipping' => 0 ,
                    'show_shipping_on_invoice' => 1,
                    'show_quantity_as' => 1,
                    'project_id' => 0,
                    'subscription_id' => 0,
                );
                
                // Array Prepare For Item Table 
                $itemMeta = array(
                    'rel_type' => 'invoice',
                    'description' => $data['invoice']['fees'][0]['item']['name'],
                    
                    'long_description' => $data['invoice']['fees'][0]['item']['name'] . ' , Item type is :' . $data['invoice']['fees'][0]['item']['item_type'],
                    
                    'qty' => $data['invoice']['fees'][0]['units'],
                    'rate' => $data['invoice']['fees'][0]['unit_amount_cents']/100,
                    'unit' => intval($data['invoice']['fees'][0]['units']),
                    'item_order' => 1,
                );
                
                // Lago data Insert 
                $lagoArray = array(
                    'lago_id' => $data['invoice']['lago_id'],
                    'client_id'   =>   $data['invoice']['customer']['external_id'],
                    'customer_lago_id' => $data['invoice']['customer']['lago_id'],
                    'slug'  => $data['invoice']['customer']['slug'],
                    'lago_invoice_id' => $data['invoice']['fees'][0]['lago_invoice_id'],
                    'lago_item_id' => $data['invoice']['fees'][0]['item']['lago_item_id'],
                );
                
                // Send to model for Opration
                $isInserted = $this->lago_model->get($invoiceData , $itemMeta ,$lagoArray);
                
                // Check for Success
                if ($isInserted > 0) {
                    $response = array(
                        'status' => true,
                        'message' => 'Data inserted successfully!',
                    );
                } else {
                    $response = array(
                        'status' => false,
                        'message' => 'Insertion failed!',
                    );
                }
        }elseif (isset($data['invoice']) && $this->input->method() == 'post' && $isCheck == false) {
            $response = array(
                'status' => true,
                'message' => 'Invoice already exists',
            );
        }else{
            $response = array(
                'status' => false,
                'message' => 'data format not match',
            );
        }
        // Send JSON response
        header('Content-Type: application/json');
        echo json_encode($response);

    }
}
