<?php


defined('BASEPATH') or exit('No direct script access allowed');

class Hyperswitch extends AdminController
{
    public function __construct()
    {
        die("tanha");
        parent::__construct();
        $this->load->model('hyperswitch_model');
        $this->load->model('staff_model');
    }

    /**
     *  leaders table
     *  
     *  @return json
     */

    

    /**
     * delete commission policy
     *
     * @param      <type>  $id     The identifier
     */
    
//     public function update_leaders_info($id){


// 		if (!has_permission('manage_new_leader', '', 'edit') && !is_admin() ) {
//             access_denied('manage_new_leader');
//         }

//         $this->load->model('staff_model');
//         $this->load->model('Leaders_model');


//         if ($this->input->post()) {

//             $data = $this->input->post();

      
//             if (!has_permission('manage_new_leader', '', 'edit')) {
//                 access_denied('manage_new_leader');
//             }

//             $success = $this->Leaders_model->update_leader($data, $id);

//             if ($success) {
//                 set_alert('success', _l('updated_successfully', _l('leader_info')));
//             }
//             redirect(admin_url('leaders'));
//         }
        
//         $this->db->where('id',$id);
//         $result = $this->db->get(db_prefix() . 'leaders')->row();

    

//         $data['is_client'] = 0;
//         $data['staffs'] = $this->staff_model->get('', ['active' => 1]);
//         $data['teamsname'] = $this->Leaders_model->get_team();
// 		$data['leaders'] = $this->Leaders_model->load_leaders($id);
// 		$data['clients'] = $this->staff_model->get($result->staffid);
// 		$data['results'] = $result;
       
//         $this->load->view('manage_new_leader', $data);

// 	}

    // public function delete_leaders_info($id){
       

    //     if (!has_permission('leaders', '', 'delete')) {
    //         access_denied('leaders');
    //     }
    //     if (!$id) {
    //         redirect(admin_url('leaders'));
    //     }
    //     $this->load->model('Leaders_model');
    //     $success = $this->Leaders_model->delete_leader($id);
    //     if ($success == true) {
    //         set_alert('success', _l('deleted', _l('applicable_leader')));
    //     } else {
    //         set_alert('warning', _l('problem_deleting', _l('applicable_leader')));
    //     }
    //     redirect(admin_url('leaders'));

    // }

    // public function manage_new_team(){

    //     if (!has_permission('manage_new_team', '', 'create') && !is_admin() ) {
    //         access_denied('manage_new_team');
    //     }

    //     $this->load->model('Leaders_model');
    //     $data['parents_id'] = get_staff_user_id();
    //     $data ['test'] = $this->db->select('role')->where('staffid' , $data['parents_id'] )->from('tblleaders')->get()->row()->role;
    //     $data ['leaderteamname'] = $this->db->select('teamname')->where('staffid' , $data['parents_id'] )->from('tblleaders')->get()->row()->teamname;

    //     if ($this->input->post()) {

    //         $data  = $this->input->post();

          

    //         $success = $this->Leaders_model->add_team_name($data);

    //         if ($success) {
    //             set_alert('success', _l('added_successfully', _l('team_list')));
    //         }
    //         redirect(admin_url('leaders/manage_team'));
    //     }
            
    //     $data['staffs'] = $this->staff_model->get('', ['active' => 1]);
        
    //     $this->load->view('manage_new_team' , $data );

    // }

    // public function manage_team() { 

    //     if (!has_permission('leaders', '', 'view')) {
    //         access_denied('leaders');
    //     }
    //     $this->load->model('Leaders_model');
    //     $data['leader'] = $this->Leaders_model->get_team();

    //     $data['staffs'] = $this->staff_model->get('', ['active' => 1]);
    //     $this->load->view('manage_team' , $data );
    // }

    // public function team_table()
    // {
    //     if (!has_permission('leaders', '', 'view')) {
    //         access_denied('leaders');
    //     }
    //         $row=array();
    //         $output=array();
    //         $teams = $this->Leaders_model->get_team();

    //         foreach ($teams as $value) {
    //             $row = [];
    //             $row[] =$value['teamname'];
    //             $row[] =$value['teamcode'];
    //             $options = icon_btn('Leaders/update_team_info/' . $value['id'], 'edit', 'btn-default', ['title' => _l('edit')]);
    //             $options .= icon_btn('Leaders/delete_team_info/' . $value['id'], 'remove', 'btn-danger', ['title' => _l('delete')]);
                
    //             $options.= icon_btn('Leaders/tree_view/'. $value['id'], 'info', 'btn-info', ['title' => _l('tree_view')]);
                

    //             $row[] =  $options;
    //             $output['aaData'][] = $row;
    //         }
           
    //         echo json_encode($output);
    //         die();
    //         $this->load->view('manage_team' , $output['aaData'][]);
    // }

 





}



