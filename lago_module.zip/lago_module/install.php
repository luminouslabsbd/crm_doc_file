<?php

defined('BASEPATH') or exit('No direct script access allowed');


// Insert lago_invoice Table For Lago Invoice - Hide
if (!$CI->db->table_exists(db_prefix() . 'lago_invoice')) {
	$CI->db->query('CREATE TABLE `' . db_prefix() . "lago_invoice` (
        `id`                bigint(11) NOT NULL AUTO_INCREMENT,
        `lago_id`           varchar(255) NOT NULL ,
        `client_id`         INT(11)        NOT NULL,
        `customer_lago_id`  varchar(255) NOT NULL ,
        `lago_invoice_id`   varchar(255) NOT NULL ,
        `lago_item_id`      varchar(255) NOT NULL ,
        
        `invoice_id`        INT(11)        NOT NULL,
        `invoice_number`    INT(11)        NOT NULL,
        `slug`              varchar(255) NOT NULL ,
    )
    
    ENGINE=InnoDB DEFAULT CHARSET=" . $CI->db->char_set . ';');

}

