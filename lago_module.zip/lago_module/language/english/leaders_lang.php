<?php

$lang['hyperswitch']         = 'Hyper Switch Payment';
$lang['manage_leaders']      = 'Manage Leaders';
$lang['title']               = 'Leader List';



