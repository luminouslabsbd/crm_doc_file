<?php

/**
 * Ensures that the module init file can't be accessed directly, only within the application.
 */
defined('BASEPATH') or exit('No direct script access allowed');
require(__DIR__ . '/vendor/autoload.php');
/*
Module Name: Lago API
Description: Sample module description.
Version: 2.3.0
Requires at least: 2.3.*
*/

define('LAGO_MODULE_NAME', 'lago_module');

$CI = &get_instance();

// hooks()->add_action('admin_init', 'lago_module_admin_init_menu_item');
// hooks()->add_action('admin_init', 'lago_permissions');

register_activation_hook(LAGO_MODULE_NAME, 'lago_module_activation_hook');

$CI = &get_instance();
$CI->load->helper(LAGO_MODULE_NAME . '/lago');



function lago_module_activation_hook()
{
    $CI = &get_instance();
    require_once(__DIR__ . '/install.php'); 
}

/**
* Register module deactivation hook
* @param  string $module   module system name
* @param  mixed $function  function for the hook
* @return mixed
*/
// register_deactivation_hook(LAGO_MODULE_NAME, 'lago_module_deactivation_hook');
// {
    // unlink_files();
    // delete_custom_fields();
// }

// register_language_files(LAGO_MODULE_NAME, [LAGO_MODULE_NAME]);

function lago_module_admin_init_menu_item()
{
 /**
    * If the logged in user is administrator, add custom menu in main menu
    */

    if (is_admin()) {
        $CI = &get_instance();

        $CI->app->add_quick_actions_link([
            'name'       => _l('hyperswitch'),
            'url'        => admin_url('hyperswitch'),
            'position'   => 12,
        ]);

        if ( is_admin() ) {
            $CI->app_menu->add_sidebar_menu_item('hyperswitch', [
                    'slug'     => 'hyperswitch',
                    'name'     => _l('hyperswitch'),
                    'href'     => admin_url('hyperswitch/index'),
                    'position' => 13,
                    'icon'     => 'fa-solid fa-receipt',    
            ]);
        }

    }

    // function lago_permissions()
    // {
    //     $capabilities = [];
    //     $capabilities['capabilities'] = [
    //             'view'   => _l('permission_view') . '(' . _l('permission_global') . ')',
    //             'create' => _l('permission_create'),
    //             'edit'   => _l('permission_edit'),
    //             'delete' => _l('permission_delete'),
    //     ];

    //     register_staff_capabilities('lago', $capabilities, _l('hyperswitch'));
    // }

   




}
